#!/usr/bin/env bash
set -euo pipefail
mkdir -p evidence
cargo run --locked -q -p ca-evaluation --bin continuity-atlas-evaluation | tee evidence/evaluation.jsonl
